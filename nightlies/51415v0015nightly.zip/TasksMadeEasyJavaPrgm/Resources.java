public class Resources{
	//Will add more
	private final String GREETINGMESSAGE = "Welcome to Tasker!";
	private final String ADDNEWTASKMESSAGE = "Please type in the Name of the Task";
	private final String QUITMESSAGE = "Goodbye, storing Tasks";
	private final String SUCCESSMESSAGE = "Task created!";

	public String getGreetingMessage(){
		return GREETINGMESSAGE;
	}

	public String getAddNewTaskMessage(){
		return ADDNEWTASKMESSAGE;
	}

	public String getQuitMessage(){
		return QUITMESSAGE;
	}

	public String getSuccessMessage(){
		return SUCCESSMESSAGE;
	}
}