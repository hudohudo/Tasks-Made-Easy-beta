public abstract class TasksMadeEasy {
	
	private List<Task> myTasks = new ArrayList<Task>();

	public TasksMadeEasy(){

	}

	public addTasks(Task newTask){
		myTasks.add(newTask);
	}
}s